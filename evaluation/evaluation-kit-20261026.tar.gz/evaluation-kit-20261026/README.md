# 云端测试包与当前验收状态（2026-10-26）

用户最新选择：仅保存完整测试资料，使用独立测试包传服务器，不需要改GitHub或重新clone。
本轮没有上传新测试代码、没有改云端服务配置、没有重新训练或替换权重。

## 当前事实

- 8B训练完成：82条、1 epoch、21步；adapter为 `/root/autodl-tmp/models/services/qwen-light/vision/20261026-194847-896921/adapter`。
- 9B训练完成：36条、3 epochs、9步；adapter为 `/root/autodl-tmp/models/services/qwen-light/text/20261026-195051-375615/adapter`。
- 两个adapter均已在用户云端加载和生成。9B目前只核对了S01：A+B合计15g，各自未知，回答符合该题。
- 8B前三个训练样本回放出现错误描述与明显复读，当前视觉质量不通过。不能用loss下降或adapter激活代替验收。
- 本地改的是测试工具。文件不会自动同步到云端；独立包包含所需测试脚本快照，解压到新目录运行，不覆盖项目源码。
- 8B多数训练标签是主题短句，应用的VISION提示词和VisionEvidence合同要求结构化JSON，必须测试这层差异；尚不能据此确定唯一失败根因。
- 9B基座73秒、微调版2.87秒的单次耗时包含先后执行/编译/输出长度差异，不能据此宣称微调带来25倍提速。

## 保存内容

`data/vision-eval-v2/`：32张原创建模图片、64问、192个字段；48问开发回归＋16问封存测试。涵盖配料、参数设定/实测、批次、流程箭头、缺项、单位符号、证据边界和图片内注入。每图的全部问答同组同划分；检查与训练图片哈希不重合，禁止相同题目/完整参考跨划分。`review.html`可对照图片与答案。

`data/text-eval-v1/`：24道文字题，18道开发回归＋6道封存题。前12道沿用既有smoke题，补充加量提醒、计量基准、冲突、温度语义、复测充分性、身份、单位换算和注入等。每题有人工验收要点，脚本不把这些要点送给模型。

这些是合成/开发测试资料，不是真实现场检验或正式生产参数。图文封存题仍共享生成器，不能宣称跨工厂泛化。原82条已用于训练，只用于诊断回放，不能计入独立正确率。早期 `vision-eval-v1` 为本地初稿，最终包只使用完成去重检查的v2。

## 分轮顺序

1. **检查包**：哈希、图片/标注对应、划分、训练重合检查；不加载GPU。
2. **定位8B退化**：同图、同processor、同量化基座、同生成参数，关闭/开启LoRA对照。记录EOS、截断和原回答；不加复读抑制参数来掩盖失败。
3. **开发回归**：8B按应用实际VISION提示词与JSON合同测48问（两种variant共96次）；9B测18题（两种variant共36次）。逐项人工看原图和回答，保留失败与未知。Greedy/HF测试没有vLLM的JSON语法约束，HTTP接入仍须单独测。
4. **按失败原因处理**：基座正常而adapter退化，检查标签、EOS监督、训练任务和强度，必要时训练新的run；两边都失败，检查模板、图片处理、生成设置和运行栈。先有对照证据，不能直接认定只能重训。
5. **冻结方案后测封存集**：视觉16问、文本6题；不把封存题用于反复调参。如果使用其结果开发，须标为已用并另建真正未用的最终集，不能不断重测直到碰巧过关。
6. **服务验收**：完成真实未见现场图/专家复核；再核对vLLM兼容与双组件显存，测HTTP图文链路、多轮上下文、加量提醒、注入、限流/超时、前端统一选择和飞书。通过后才决定正式服务启用。

## 评分与通过边界

视觉自动核对JSON合同/图片ID、字段行列、数值、单位、缺失保留、注入警告、EOS、截断、复读。固定标签精确匹配，数值允许有限Decimal等值；同数值错单位仍失败。标签同义改写若被扣分应由人查看原回答，不允许静默放宽评分。

开发回归的暂定最低条件：完整执行本轮全部题、JSON合同全部有效、关键字段零错误、无循环复读/输出截断、字段正确率≥95%。这仅表示可进入人工核验；文本逐题核对全部review要点。模型与现场系统都不会被脚本自动批准，报告始终保留 `production_accepted=false`。实际图片真实性、领域正确性、业务适用性和现场验收另行核对。

## 单独上传、解压和运行

本地包：`reports/evaluation-kit-20261026.tar.gz`，校验文件与核验报告在同目录；不含基座、adapter、客户原件、API密钥或字体文件。
仅把tar.gz上传到 `/root/autodl-tmp/code/Cosmetics-Spray-Manufacturing-AI-System/`，不用重新clone。

```bash
cd /root/autodl-tmp/code/Cosmetics-Spray-Manufacturing-AI-System
tar --keep-old-files -xzf evaluation-kit-20261026.tar.gz
bash evaluation-kit-20261026/run_tests.sh check
bash evaluation-kit-20261026/run_tests.sh compare
```

先检查与对照，保存/查看输出再决定后续。不要把训练原图回放当作独立正确率。

```bash
# 完整开发回归：8B和9B依次执行，不同时占GPU
bash evaluation-kit-20261026/run_tests.sh regression

# 仅在开发方案冻结、人工核验完毕后执行封存测试
bash evaluation-kit-20261026/run_tests.sh final
```

入口使用已验证Python `/root/autodl-tmp/envs/cosmetics-unsloth/bin/python`，不安装依赖。报告保存在 `/root/autodl-tmp/models/services/qwen-light/evaluation/` 的全新时间目录，失败保留已有输出。脚本不下载、不训练、不启动业务服务、不覆盖项目或权重。`--keep-old-files`遇到同名目录时停止，保留原目录，不强行覆盖。

未来训练新adapter时，可通过 `COAT_EVAL_TEXT_ADAPTER` / `COAT_EVAL_VISION_ADAPTER` 指定新目录；基座路径仍显式固定在云端models。重新同步项目也只需正常git pull，原训练产物独立保存，无需重新clone。
