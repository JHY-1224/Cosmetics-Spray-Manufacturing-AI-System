#!/usr/bin/env bash
# Standalone test-only entry. Never installs, trains, overwrites or deploys.
set -euo pipefail
KIT_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
MODE="${1:-check}"
case "$MODE" in check|compare|regression|final) ;; *)
  echo 'Usage: bash run_tests.sh check|compare|regression|final' >&2; exit 2;; esac
PYTHON_BIN="${COAT_EVAL_PYTHON:-/root/autodl-tmp/envs/cosmetics-unsloth/bin/python}"
VISION_ADAPTER="${COAT_EVAL_VISION_ADAPTER:-/root/autodl-tmp/models/services/qwen-light/vision/20261026-194847-896921/adapter}"
TEXT_ADAPTER="${COAT_EVAL_TEXT_ADAPTER:-/root/autodl-tmp/models/services/qwen-light/text/20261026-195051-375615/adapter}"
TRAINING_DATA="${COAT_EVAL_TRAINING_DATA:-$KIT_DIR/../local_training/qwen-vl-20261026/metadata.jsonl}"
REPORT_BASE="${COAT_EVAL_REPORT_ROOT:-/root/autodl-tmp/models/services/qwen-light/evaluation}"
test -x "$PYTHON_BIN" || { echo 'Verified training Python not found; set COAT_EVAL_PYTHON explicitly.' >&2; exit 1; }
cd -- "$KIT_DIR"
"$PYTHON_BIN" - "$KIT_DIR" <<'PY'
import hashlib,json,sys
from pathlib import Path
root=Path(sys.argv[1]).resolve()
manifest=json.loads((root/'MANIFEST.json').read_text())
for item in manifest['files']:
    path=(root/item['path']).resolve()
    if not path.is_relative_to(root) or path.is_symlink() or hashlib.sha256(path.read_bytes()).hexdigest()!=item['sha256']:
        raise SystemExit('Test package hash/path check failed: '+item['path'])
print('Test package integrity: OK; no GPU inference performed by this check.')
PY
STAMP="$("$PYTHON_BIN" -c 'from datetime import datetime,timezone;print(datetime.now(timezone.utc).strftime("%Y%m%d-%H%M%S-%f"))')"
RUN_DIR="$REPORT_BASE/$STAMP-$MODE"
mkdir -p -- "$REPORT_BASE"
mkdir -- "$RUN_DIR"
run_step() { "$@" 2>&1 | tee -a "$RUN_DIR/terminal.log"; }
case "$MODE" in
  check)
    run_step "$PYTHON_BIN" day1/multimodal/evaluate.py --training-data "$TRAINING_DATA" \
      --adapter "$VISION_ADAPTER" --output "$RUN_DIR/preflight"
    ;;
  compare)
    run_step "$PYTHON_BIN" -u day1/multimodal/verify_vl.py --adapter "$VISION_ADAPTER" \
      --data "$TRAINING_DATA" --compare-base --output "$RUN_DIR/vision-paired.json"
    cat -- "$RUN_DIR/vision-paired.json"
    ;;
  regression|final)
    SPLIT=development
    LOCK_ARGS=()
    if [ "$MODE" = final ]; then
      SPLIT=locked
      LOCK_ARGS=(--unlock-locked)
      echo 'Sealed test selected: freeze development decisions first. Do not tune repeatedly on these results.'
    fi
    run_step "$PYTHON_BIN" -u day1/multimodal/evaluate.py --training-data "$TRAINING_DATA" \
      --adapter "$VISION_ADAPTER" --split "$SPLIT" "${LOCK_ARGS[@]}" \
      --output "$RUN_DIR/vision" --run
    run_step "$PYTHON_BIN" -u day1/4-validation/3-test-adapter.py --adapter "$TEXT_ADAPTER" \
      --base-dir /root/autodl-tmp/models/Qwen3.5-9B --cases "data/text-eval-v1/$SPLIT.json" \
      --report-dir "$RUN_DIR/text" --run
    ;;
esac
echo "Reports saved: $RUN_DIR"
echo 'Execution finished. Model quality and production acceptance still require review; no service was deployed.'
